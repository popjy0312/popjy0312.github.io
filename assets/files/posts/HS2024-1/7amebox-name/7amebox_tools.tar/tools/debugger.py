import os
import sys
import binascii
import readline

from utils import seven_to_eight_str
from _7amebox import EMU, PERM_EXEC
from disassembler import Disassembler

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class Debugger:
    def __init__(self, firmware):
        self.firmware = firmware
        self.emulator = self.initialize_emulator(firmware)
        self.disassembler = Disassembler(self.emulator, firmware)
        self.breakpoints = set()
        self.before_command = None
        self.instruction = self.setup_instructions()

    def initialize_emulator(self, firmware):
        emulator = EMU()

        emulator.filesystem.load_file('flag')
        emulator.register.init_register()
        emulator.init_pipeline()
        emulator.set_mitigation(nx=True)
        emulator.load_firmware(firmware)
        return emulator

    def setup_instructions(self):
        return {
            'r': self.restart,
            'ni': self.next_instruction,
            'b': self.set_breakpoint,
            'd': self.remove_breakpoint,
            'c': self.run_until_breakpoint,
            'x': self.memdump,
            'set': self.set_memory,
            'reg': self.info_register,
            'q': exit,
        }

    def run(self, script=None):
        self.print_screen()
        pre_commands = script.strip().split('\n') if script else []
        for command in pre_commands:
            args = self.parse_arguments(command[1:])
            if args is not None:
                try:
                    self.instruction[command[0]](*args)
                except Exception:
                    pass
            self.before_command = command

        while True:
            command = raw_input("> ").split()
            if not command:
                pass
                # command = self.before_command
            args = self.parse_arguments(command[1:])
            if args is not None:
                try:
                    self.instruction[command[0]](*args)
                except Exception as e:
                    print(e)
                    pass
            self.before_command = command

    def parse_arguments(self, command_args):
        args = []
        for idx, arg in enumerate(command_args):
            parsed_arg = self.parse_argument(idx, arg)
            if parsed_arg is None:
                return None
            args.append(parsed_arg)
        return args

    def parse_argument(self, idx, arg):
        if arg.startswith('0x'):
            return int(arg, 16)
        elif arg.startswith('0b'):
            return int(arg, 2)
        elif arg.startswith('$'):
            if idx == 0:
                return arg[1:]
            else:
                return self.get_register_value(arg[1:])
        elif arg.startswith('bin'):
            return binascii.unhexlify(arg[3:])
        else:
            return self.parse_int(arg)

    def get_register_value(self, reg_name):
        try:
            assert reg_name in self.emulator.register.register_list, 'Invalid register'
            return self.emulator.register.get_register(reg_name)
        except Exception as e:
            print e
            return None

    def parse_int(self, arg):
        try:
            return int(arg)
        except ValueError:
            print 'Invalid argument'
            return None

    def print_screen(self):
        print '-' * 0x40
        self.print_instructions()
        print '-' * 0x40
        self.print_stack()
        print '-' * 0x40
        self.info_register('all')
        print '-' * 0x40

    def print_instructions(self):
        tmp_pc = self.emulator.register.get_register('pc')
        for _ in range(10):
            line = self.disassembler.instruction(tmp_pc)
            print line
            _, _, _, op_size = self.emulator.dispatch(tmp_pc)
            tmp_pc += op_size

    def restart(self):
        self.emulator = self.initialize_emulator(self.firmware)
        self.print_screen()

    def next_instruction(self, print_screen = True):
        cur_pc = self.emulator.register.get_register('pc')
        op, op_type, opers, op_size = self.emulator.dispatch(cur_pc)
        if not self.check_memory_permission(cur_pc, op_size):
            self.emulator.terminate("[VM] Can't exec memory")
        self.emulator.register.set_register('pc', cur_pc + op_size)
        self.emulator.op_hander_table[op](op_type, opers)
        if print_screen:
            self.print_screen()

    def check_memory_permission(self, cur_pc, op_size):
        return (self.emulator.memory.check_permission(cur_pc, PERM_EXEC) and
                self.emulator.memory.check_permission(cur_pc + op_size - 1, PERM_EXEC))

    def set_breakpoint(self, pc):
        self.breakpoints.add(pc)

    def run_until_breakpoint(self, cnt=1):
        while True:
            self.next_instruction(print_screen=False)
            if self.emulator.register.get_register('pc') in self.breakpoints:
                cnt -= 1
                if cnt == 0:
                    break
        self.print_screen()

    def hexdump(self, base_addr, data):
        out = ''
        for i in range(0, len(data), 16):
            line = data[i:i+16]
            hexa = ' '.join('%02x' % b for b in line)
            ascii = ''.join(chr(b) if 32 <= b < 127 else '.' for b in line)
            out += '%08x: %s %s\n' % (base_addr+i, hexa.ljust(48), ascii)
        return out

    def get_memory(self, addr, length):
        return self.emulator.memory[addr: addr + length]
    
    def set_memory(self, addr, data):
        for i in range(len(data)):
            self.emulator.memory[addr + i] = ord(data[i])

    def memdump(self, addr, length):
        mem = self.get_memory(addr, length)
        print self.hexdump(addr, mem)

    def info_register(self, reg='all'):
        register_list = self.emulator.register.register_list
        if reg == 'all':
            for reg in register_list:
                print '%s = %s' % (reg, hex(self.emulator.register.get_register(reg)))
        elif reg not in register_list:
            print 'Invalid register'
        else:
            print '%s = %s' % (reg, hex(self.emulator.register.get_register(reg)))

    def print_stack(self):
        sp = self.emulator.register.get_register('sp')
        for i in range(0x3):
            addr = sp + i * 3
            data = self.get_memory(addr, 3)
            hexa = ' '.join('%02x' % b for b in data)
            print '%08x: %s | %s' % (addr, hexa, seven_to_eight_str(data))

    def remove_breakpoint(self, pc):
        self.breakpoints.remove(pc)
