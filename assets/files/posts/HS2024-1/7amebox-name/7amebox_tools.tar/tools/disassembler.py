import os
import sys
from _7amebox import EMU, TYPE_R, TYPE_I

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class Disassembler(object):
    def __init__(self, emulator=None, firmware=None):
        super(Disassembler, self).__init__()
        self.op_list = {
            'op_x0': 'load',
            'op_x1': 'load7',
            'op_x2': 'store',
            'op_x3': 'store7',
            'op_x4': 'mov',
            'op_x5': 'xchg',
            'op_x6': 'push',
            'op_x7': 'pop',
            'op_x8': 'syscall',
            'op_x9': 'add',
            'op_x10': 'add7',
            'op_x11': 'sub',
            'op_x12': 'sub7',
            'op_x13': 'shr',
            'op_x14': 'shl',
            'op_x15': 'mul',
            'op_x16': 'div',
            'op_x17': 'inc',
            'op_x18': 'dec',
            'op_x19': 'and',
            'op_x20': 'or',
            'op_x21': 'xor',
            'op_x22': 'mod',
            'op_x23': 'cmp',
            'op_x24': 'cmp7',
            'op_x25': 'jg',
            'op_x26': 'jl',
            'op_x27': 'je',
            'op_x28': 'jne',
            'op_x29': 'jmp',
            'op_x30': 'call',
        }
        if emulator is None:
            self.emulator = EMU()
            self.emulator.filesystem.load_file('flag')
            self.emulator.register.init_register()
            self.emulator.init_pipeline()
            self.emulator.load_firmware(firmware)
        else:
            self.emulator = emulator
        self.regi_list = self.emulator.register.register_list

    def disassemble(self, pc):
        addr = pc
        opcode = self.bit_concat(self.emulator.read_memory(addr, 2))
        op      = (opcode & 0b11111000000000) >> 9
        if op >= 31:
            return None, None, [], 1, [self.emulator.memory[addr]]

        op_type = (opcode & 0b00000100000000) >> 8
        opers   = []
        if op_type == TYPE_R:
            opers.append((opcode & 0b00000011110000) >> 4)
            opers.append((opcode & 0b00000000001111))
            op_size = 2

        elif op_type == TYPE_I:
            opers.append((opcode & 0b00000011110000) >> 4)
            opers.append(self.emulator.read_memory_tri(addr+2, 1)[0])
            op_size = 5

        else:
            return None, None, [], 1, [self.emulator.memory[addr]]
        return op, op_type, opers, op_size, self.emulator.memory[addr:addr+op_size]

    def instruction(self, pc):
        op, op_type, opers, op_size, bytecode = self.disassemble(pc)
        
        bytecode = ' '.join([format(b, '02x') for b in bytecode]).ljust(16)
        try:
            operation = self.get_operation_name(op)

            operands = self.get_operand(op, op_type, opers)
            operands_string = ", ".join(operands)

            if operation in ['call', 'jmp', 'jg', 'jl', 'je', 'jne'] and operands[0] == 'pc':
                return '0x{:04x} : {}| {} {} ; 0x{:04x}'.format(pc, bytecode, operation.ljust(8), operands_string.ljust(12), (pc + op_size + int(operands[1], 16)))
            else:
                return '0x{:04x} : {}| {} {}'.format(pc, bytecode, operation.ljust(8), operands_string.ljust(12))
        except Exception as e:
            return '0x{:04x} : {}| Invalid opcode'.format(pc, bytecode)

    def get_operation_name(self, op):
        return self.op_list['op_x{}'.format(op)]

    def get_register_name(self, regi):
        return self.regi_list[regi]

    def get_operand(self, op, op_type, opers):
        """ return (dst, src)"""
        if op in [8]:    # no operand
            return []
        elif op in [6, 7, 17, 18]:    # 1 operand
            if op_type == TYPE_R:
                return [self.regi_list[opers[0]]]
            elif op_type == TYPE_I:
                return [self.regi_list[opers[1]]]
        else:
            if op_type == TYPE_R:
                return [self.regi_list[opers[0]], self.regi_list[opers[1]]]
            elif op_type == TYPE_I:
                if opers[1] & 0b100000000000000000000:
                    return [self.regi_list[opers[0]], '-' + hex(2**21 - opers[1])]
                else:
                    return [self.regi_list[opers[0]], hex(opers[1])]

    def disas_all(self):
        pc = self.emulator.register.get_register('pc')
        while pc < len(self.emulator.firmware):
            print(self.instruction(pc))
            pc += self.disassemble(pc)[3]

    def disas_interval(self, start, end):
        pc = start
        while pc < end:
            print(self.instruction(pc))
            pc += self.disassemble(pc)[3]

    def bit_concat(self, bit_list):
        res = 0
        for bit in bit_list:
            res <<= 7
            res += bit & 0b1111111
        return res
