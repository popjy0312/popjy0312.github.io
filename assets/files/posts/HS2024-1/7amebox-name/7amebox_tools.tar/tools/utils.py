def seven_to_eight_list(data):  # type: (list) -> list
    assert len(data) == 3, "Data length should be 3, but got {}".format(len(data))
    number = data[0] | (data[1] << 14) | (data[2] << 7)
    return [number & 0xff, (number >> 8) & 0xff, (number >> 16) & 0xff]

def seven_to_eight_str(data):  # type: (list) -> str
    out = ''
    for c in seven_to_eight_list(data)[::-1]:
        out += hex(c)[2:].rjust(2, '0')
    return out

def eight_to_seven_int(num):  # type: (int) -> int
    return eight_to_seven(num)[0] | (eight_to_seven(num)[1] << 8) | (eight_to_seven(num)[2] << 16)

def eight_to_seven(num):  # type: (int) -> list
    return [num & 0b000000000000001111111, (num & 0b111111100000000000000) >> 14, (num & 0b000000011111110000000) >> 7]

def p21(num):  # type: (int) -> str
    return num.to_bytes(3, 'little')

def u21(data):  # type: (str) -> int
    return int.from_bytes(data, 'little')

def encode_seven(num):  # type: (int) -> str
    return p21(eight_to_seven_int(num))